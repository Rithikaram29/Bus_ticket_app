import Bus from "../models/busModel";
import { User, UserRole } from "../models/userDetailModel";
import { Request, RequestHandler, Response } from "express";
import { Types } from "mongoose";
import DataQueryAbstraction from "../abstraction/databaseMethodAbstraction";
import DateModel from "../models/calendarModel";

const busServices = new DataQueryAbstraction(Bus);
const userControl = new DataQueryAbstraction(User);
const dateControl = new DataQueryAbstraction(DateModel);

//interface structure
enum SeatType {
  SingleSleeper = "single sleeper",
  DoubleSleeper = "double sleeper",
  Seater = "seater",
}

interface SelectedSeat {
  seatNumber: string;
  userid: Types.ObjectId;
}

interface Seat {
  seatNumber: string;
  availability: boolean;
  seatType: SeatType;
  seatPrice: number;
  assignedTo: Types.ObjectId | undefined;
}

interface CustomRequest extends Request {
  user?: { _id: Types.ObjectId; email: string; role: string };
}

// To book tickets
const bookTicket = async (req: CustomRequest, res: Response) => {
  const date = req.body.date;
  if (!date) {
    throw new Error("Date missing");
  }

  const busId = req.params.id; //assuming once we are directed to the bus page, the id is added in the params
  const userId: any = req.user?._id;
  const role = req.user?.role;
  if (role !== UserRole.CUSTOMER) {
    throw new Error("Not Authorised");
  }
  try {
    //check for user
    const currentUser: any = await userControl.findById(userId);
    if (!currentUser) {
      res.status(404).json({ error: "User not found!" });
      return;
    }

    //check for bus
    const currentBus: any = await busServices.findById(busId);
    if (!currentBus) {
      res.status(404).json({ error: "bus not found" });
      return;
    }

    const customerSeats: SelectedSeat[] = req.body.seats; //req.body will contain object with key as seats and value as array of selected seats.
    //structure of the incoming req.body will be {date: "date",seats:[{seatNo:"", name:"", phone:"", email:""},{seatNo:"", name:"", phone:"", email:""}]}

    //getting the seatnumber to be booked.
    const customerSeatNumbers = customerSeats.map(
      (selSeat: any) => selSeat.seatNumber
    );

    //using the selected seatnumber to check if that is already booked to avoid error
    const alreadyBookedSeats = currentBus
      ? currentBus.seats.filter(
          (seat: any) =>
            customerSeatNumbers.includes(seat.seatNumber) &&
            seat.availability === false
        )
      : [];

    if (alreadyBookedSeats.length > 0) {
      res.status(404).json({
        error: "Some seats are already booked",
        seatNum: alreadyBookedSeats.map((seat: any) => seat.seatNumber),
      });
      return;
    } else {
      currentBus
        ? currentBus.seats.map((seat: Seat) => {
            if (customerSeatNumbers.includes(seat.seatNumber)) {
              seat.availability = false;
              const matchingSeat = customerSeats.filter(
                (selSeat) => selSeat.seatNumber === seat.seatNumber
              );
              if (matchingSeat.length > 0) {
                seat.assignedTo = userId;
              }

              //add ticktes to the user's id
              const ticket = { busId: busId, seats: customerSeatNumbers };
              userControl.findOneAndUpdate(
                { _id: userId },
                { $push: { tickets: ticket } }
              );
            }
          })
        : [];
    }

    //saving the updated tickets
    busServices.save(currentBus);

    //populating the bus with the assigned users
    busServices.populate(
      { _id: busId },
      { path: "seats.assignedTo", model: "User" }
    );

    res.status(200).json({ message: "Tickets booked successfully!" });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//To cancel tickets

const cancelTicket = async (req: CustomRequest, res: Response) => {
  const busId = req.params.id; //assuming once we are directed to the bus page, the id is added in the params
  const userId: any = req.user?._id;
  const role = req.user?.role;
  if (role !== UserRole.CUSTOMER) {
    throw new Error("Not Authorised");
  }
  try {
    const currentBus: any = await busServices.findById(busId);

    if (!currentBus) {
      res.status(404).json({ error: "bus not found" });
    }

    const customerSeats: SelectedSeat[] = req.body.seats; //req.body will contain object with key as seats and value as array of selected seats.
    //structure of the incoming req.body will be {seats:[{seatNo:"", name:"", phone:"", email:""},{seatNo:"", name:"", phone:"", email:""}]}

    //getting the seatnumber to be booked.
    const customerSeatNumbers = customerSeats.map(
      (selSeat: any) => selSeat.seatNumber
    );

    //using the eselected seatnumber to check if that is already booked to avoid error
    const notBookedSeats = currentBus
      ? currentBus.seats.filter(
          (seat: any) =>
            customerSeatNumbers.includes(seat.seatNumber) &&
            seat.availability === true
        )
      : [];

    if (notBookedSeats.length > 0) {
      res.status(404).json({
        error: "Some seats are not booked by you",
        seatNum: notBookedSeats.map((seat: any) => seat.seatNumber),
      });
      return;
    } else {
      currentBus
        ? currentBus.seats.map((seat: any) => {
            if (customerSeatNumbers.includes(seat.seatNumber)) {
              (seat.availability = true), (seat.assignedTo = undefined);
            }
          })
        : [];
    }

    busServices.save(currentBus);

    res.status(200).json({ message: "Tickets canceled successfully!" });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//Get bus details
const getBusdetails: RequestHandler = async (
  req: CustomRequest,
  res: Response
): Promise<void> => {
  try {
    // Extract query parameters
    const { from, to, date } = req.query;

    // Validate input parameters
    if (!date || !from || !to) {
      res
        .status(400)
        .json({ error: "Missing required parameters: date, from, or to." });
      return;
    }

    // Fetch the Calendar for the given date
    const calendar: any = await dateControl.find({ date });
    // console.log(calendar);

    if (!calendar || calendar.length === 0 || !calendar[0].bus) {
      res
        .status(404)
        .json({ error: "No bookings or buses available for the given date." });
      return;
    }

    // Initialize an empty array to store buses
    const buses = [];

    // Iterate over each bus in the calendar
    for (const entry of calendar[0].bus) {
      const busNo = entry.busNo;

      // Fetch the bus details from the Bus collection by busNo
      const bus: any = await busServices.find({ busno: busNo });

      const leanBus = await bus.lean()
      console.log( leanBus)
      if (bus) {
        // Safeguard against missing pickup or drop arrays
        const pickupCities = Array.isArray(bus.pickup)
          ? bus.pickup.map((pickup: any) => pickup.city.toLowerCase())
          : [];

        console.log(bus.pickup);
        const dropCities = Array.isArray(bus.drop)
          ? bus.drop.map((drop: any) => drop.city.toLowerCase())
          : [];

        // Check if the bus serves the requested route
        if (
          pickupCities.includes((from as string).toLowerCase()) &&
          dropCities.includes((to as string).toLowerCase())
        ) {
          // Update seat availability based on booked seats
          const bookedSeatNumbers = entry.bookedSeats.map(
            (seat: any) => seat.seatNumber
          );

          // Mark seats as unavailable if they are booked
          bus.seats = Array.isArray(bus.seats)
            ? bus.seats.map((seat: any) => {
                if (bookedSeatNumbers.includes(seat.seatNumber)) {
                  seat.availability = false; // Mark seat as unavailable
                }
                return seat;
              })
            : [];

          // Add the bus to the array of buses
          buses.push(bus);
        }
      }
    }

    if (buses.length === 0) {
      res
        .status(404)
        .json({ error: "No buses available for the selected route." });
      return;
    }

    // Return the updated list of buses with seat availability
    res.status(200).json(buses);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export { bookTicket, cancelTicket, getBusdetails };
