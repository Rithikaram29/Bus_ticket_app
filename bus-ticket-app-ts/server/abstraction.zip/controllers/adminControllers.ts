import Bus from "../models/busModel";
import { Request, RequestHandler, Response } from "express";
import { User, UserRole } from "../models/userDetailModel";
import { Types } from "mongoose";
import DateModel from "../models/calendarModel";
import DataQueryAbstraction from "../abstraction/databaseMethodAbstraction";
import { error } from "console";


const busServices = new DataQueryAbstraction(Bus);
const userControl = new DataQueryAbstraction(User);
const calendarServices = new DataQueryAbstraction(DateModel);

interface CustomRequest extends Request {
  user?: { _id: Types.ObjectId; email: string; role: string };
}

//creating the bus
const createBus: RequestHandler = async (
  req: CustomRequest,
  res: Response
): Promise<void> => {
  try {
    const userId: any = req.user?._id;
    const role = req.user?.role;

    if (role !== UserRole.ADMIN) {
      res.status(403).json({ error: "Not Authorized" });
      return;
    }

    if (!userId) {
      res.status(400).json({ error: "User Does Not Exist!" });
      return;
    }

    // Check for existing bus
    const existingBus = await busServices.find({ busno: req.body.busno });
    if (existingBus.length > 0) {
      res.status(400).json({ error: "Bus already exists!" });
      return;
    }

    // Create the new bus
    const newBus = await busServices.create(req.body);
    if (!newBus) {
      res.status(400).json({ error: "Cannot create Bus!" });
      return;
    }

    // Add bus to user
    const newBusId = newBus._id;
    await userControl.findOneAndUpdate(
      { _id: userId },
      { $push: { bus: newBusId } }
    );

    // Respond with the newly created bus
    res.status(201).json(newBus);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//add bus to dates
const addBusToCalendarDates: RequestHandler = async (
  req: CustomRequest,
  res: Response
): Promise<void> => {
  try {
    const { dates, busNo } = req.body;

    if (!Array.isArray(dates) || dates.length === 0 || !busNo) {
      res.status(400).json({ error: "Invalid or missing dates array or busNo." });
      return;
    }

    const calendarEntries = dates.map(async (date: string) => {
      const existingCalendar = await calendarServices.find({ date });

      if (existingCalendar.length > 0) {
        // Update existing calendar entry
        await calendarServices.update(
          { date },
          { $push: { bus: { busNo, bookedSeats: [] } } }
        );
      } else {
        // Create new calendar entry
        const newCalendar: any = {
          date,
          bus: [{ busNo, bookedSeats: [] }],
        };
        await calendarServices.create(newCalendar);
      }
    });

    await Promise.all(calendarEntries); // Ensure all calendar updates/creates are complete

    res.status(200).json({ message: "Bus ID added to selected dates." });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//resetting the bus tickets
const resetTickets: RequestHandler = async (
  req: CustomRequest,
  res: Response
) => {
  const busId = req.params.id;
  const { date } = req.body;
  try {
    const currentDay: any = calendarServices.find({ date: date });

    if (!currentDay || currentDay.length === 0) {
      res.status(404).json({ error: "Date not found in the calendar." });
      return;
    }

    //buses for the day
    const buses = currentDay[0].bus;

    //Finding our bus
    const currentBus = buses.find((bus: any) => bus.busId.toString() === busId);

    if (!currentBus) {
      res.status(404).json({ error: "Could not find bus." });
      return;
    }

    currentBus.bookedSeats = [];

    await calendarServices.update(
      { date },
      { $set: { "bus.$[elem].bookSeats": [] } },
      { arrayFilters: [{ "elem.busId": busId }] }
    );

    res.status(200).json({ message: "Tickets reset successful." });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//get buses
const getBuses: RequestHandler = async (req: CustomRequest, res: Response) => {
  try {
    let role: string | undefined = req.user?.role;

    if (role !== "admin") {
      res.status(403).json({ error: "Not Authorised!" });
      return;
    }

    const userId = req.user?._id;
    let currentUser: any = userControl.find({ _id: userId });

    const buses = currentUser.bus;
    if (!buses) {
      res.status(404).json({ error: "Could not find buses" });
      return;
    }

    res.status(202).json(buses);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

//get bus detail for particular date
const getBusdetails: RequestHandler = async (
  req: CustomRequest,
  res: Response
): Promise<void> => {
  const role = req.user?.role;

  // Check if the user has admin privileges
  if (role !== "admin") {
    res.status(403).json({ error: "Not Authorised!" });
    return;
  }

  try {
    const date = req.params.date;

    // Step 1: Fetch all buses on the provided date
    const currentDate: any = await calendarServices.populate(
      { date: date.toString() },
      {path:"bus.busId",
      model:Bus}
    );

    if (!currentDate || !currentDate.bus) {
      res.status(404).json({ error: "Could not find any buses on this date!" });
      return;
    }

    const allBuses = currentDate.bus;
    if(!allBuses){
      res.status(404).json({error:"Missing bus in date!"});
      return;
    }

    // Step 2: Fetch user data and get the list of bus IDs managed by the user
    const userId = req.user?._id;
    const currentUser: any = await userControl.populate({_id: userId},{path:"bus",model:"User"});
    if (!currentUser || !currentUser.bus || currentUser.bus.length === 0) {
      res.status(404).json({ error: "Could not find any buses under admin!" });
      return;
    }

    const managedBusIds = currentUser.bus.map((bus: any) => bus._id.toString());

    // Step 3: Filter buses managed by the admin
    const currentBuses = allBuses.filter((busEntry: any) =>
      managedBusIds.includes(busEntry.busId._id.toString())
    );

    if (!currentBuses.length) {
      res.status(404).json({ error: "No buses found on this date!" });
      return;
    }

    // Step 4: Update seat availability based on bookedSeats
    const updatedBuses = currentBuses.map((busEntry: any) => {
      const bus = busEntry.busId;
      const bookedSeats = busEntry.bookedSeats.map((seat: any) => seat.seatNumber);

      // Update seat availability
      bus.seats = bus.seats.map((seat: any) => {
        if (bookedSeats.includes(seat.seatNumber)) {
          seat.availability = false; // Mark seat as unavailable
          seat.bookedBy = busEntry.bookedSeats.find(
            (bookedSeat: any) => bookedSeat.seatNumber === seat.seatNumber
          )?.bookedBy; // Add booking details
        }
        return seat;
      });

      return bus;
    });

    // Step 5: Send updated bus details
    res.status(200).json(updatedBuses);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};


export { createBus, resetTickets, getBuses, getBusdetails, addBusToCalendarDates };
