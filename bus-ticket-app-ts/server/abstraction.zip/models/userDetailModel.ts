import mongoose, { Model, Document, Schema, Types } from "mongoose";
import SchemaAbstraction from "../abstraction/modelAbstraction";
import { ObjectId } from "mongodb";

const schemaAbstraction = new SchemaAbstraction();

enum UserRole {
  ADMIN = "admin",
  CUSTOMER = "customer",
}

type UserRoleType = keyof typeof UserRole;

//interface for typeScript
interface ITickets extends Document {
  busId: Types.ObjectId | string;
  seats: string[];
}

interface NewUser extends Document {
  userName: string;
  phone: number;
  email: string;
  password: string;
  role: UserRole;
  name?: string;
  tickets?: ITickets[];
  bus?: Types.ObjectId[];
}

schemaAbstraction.defineSchema("User", {
  userName: {
    type: String,
    required: true,
    unique: true,
  },
  phone: {
    type: Number,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: Object.values(UserRole),
  },

  name: { type: String },

  tickets: [
    {
      busId: {
        type: String ,
        required: false,
      },
      seats: [
        {
          type: String,
          validate: {
            validator: function (this: any, value: any) {
              return !!this.busId;
            },
            message: "Need busId to save seats",
          },
        },
      ],
    },
  ],

  bus: [
    {
      type: Types.ObjectId,
      ref:"Bus",
      required: false
    }
  ]
});

const User: Model<NewUser> = schemaAbstraction.getModel("User");

export { User, UserRole };
