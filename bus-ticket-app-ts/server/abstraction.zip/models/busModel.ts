import mongoose, { Model, Types } from "mongoose";
import SchemaAbstraction from "../abstraction/modelAbstraction";
import { User, UserRole } from "./userDetailModel";

const schemaAbstraction = new SchemaAbstraction();
//interface
interface AssignedTo {
  userName: string;
  email: string;
  role: UserRole;
  name?: string;}

interface Seat extends Document {
  seatNumber: string;
  availability: boolean;
  seatType: SeatType;
  seatPrice: number;
  bookedBy: AssignedTo;
  assignedTo: string;
}


enum SeatType {
  SingleSleeper = "single sleeper",
  DoubleSleeper = "double sleeper",
  Seater = "seater",
  UpperDouble = "upper double",
  UpperSingle = "upper single"
}

//Define seat Schema
const seatSchema= schemaAbstraction.createSubSchema( {
  seatNumber: {
    type: String,
    required: true,
  },
  availability: {
    type: Boolean,
    default: true,
  },
  seatType: {
    type: String,
    enum: Object.values(SeatType),
    default: SeatType.Seater,
  },
  seatPrice: {
    type: Number,
    required: true,
  },
  bookedBy: {
    type: Types.ObjectId,
    ref: "User",
    validate: {
      validator: function (this: any, value: string) {
        return this.availability || !!value;
      },
      message: "Name is required if the seat is unavailable",
    },
  },
  assignedTo:{
    type: String
  }
});

const pickUpSchema= schemaAbstraction.createSubSchema({
  city: {
    type: String,
    required: true,
  },
  landmark: [{
    time:{
      type: String, 
    required: true, 
    validate: {
      validator: function (value: string) {
        // Regex to match HH:mm format (24-hour clock)
        return /^([01]\d|2[0-3]):([0-5]\d)$/.test(value);
      },
      message: (props: any) => `${props.value} is not a valid 24-hour time format (HH:mm).`
    }
    },
    place:{
      type: String,
      required: true
    }
  }],
});


const dropSchema= schemaAbstraction.createSubSchema({
  city: {
    type: String,
    required: true,
  },
  landmark: [{
    time:{
      type: String, 
    required: true, 
    validate: {
      validator: function (value: string) {
        // Regex to match HH:mm format (24-hour clock)
        return /^([01]\d|2[0-3]):([0-5]\d)$/.test(value);
      },
      message: (props: any) => `${props.value} is not a valid 24-hour time format (HH:mm).`
    }
    },
    place:{
      type: String,
      required: true
    }
  }],
});

schemaAbstraction.defineSchema("Bus", {
  busno:{
    type: String,
    required: true,
    unique: true
  },
  name: {
    type: String,
    required: true,
  },
  pickup: {type:[pickUpSchema], required: true},
  drop:  {type:[dropSchema], required: true},
  bustype: {
    type: String,
    required: true,
  },
  isAc: {
    type: Boolean,
    default: false,
  },
  rating: {
    type: Number,
    default: 0,
  },
  seats: {type:[seatSchema], required: true},
});

const BusModel: any = schemaAbstraction.getModel("Bus");

export default BusModel;
