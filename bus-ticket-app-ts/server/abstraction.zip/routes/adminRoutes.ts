import { Router } from "express";

import {
  createBus,
  resetTickets,
  getBuses,
  addBusToCalendarDates
} from "../controllers/adminControllers";

const router = Router();

router.get("/bus", getBuses);
router.post("/bus/create", createBus);
router.post("/bus/addtodate",addBusToCalendarDates)
router.put("/ticket-reset/:id", resetTickets);

export default router;
